package com.stockmanagement.json;

public class CustomerInfoResponse {
	private String dirtyStatus;

	public String getDirtyStatus() {
		return dirtyStatus;
	}

	public void setDirtyStatus(String dirtyStatus) {
		this.dirtyStatus = dirtyStatus;
	}

}
